/* Sabre Radar – envoi des pages En Garde vers GitHub */
const DEF = { owner: "rcampazzi-lang", repo: "sabre-radar", branch: "main", folder: "imports", token: "" };
const cfg = async () => Object.assign({}, DEF, await chrome.storage.local.get(Object.keys(DEF)));

/* Exécuté DANS la page : renvoie le HTML allégé de la page (ou de toutes les pages de l'épreuve) */
function grab(all) {
  const clean = (html) => {
    const d = new DOMParser().parseFromString(html, "text/html");
    d.querySelectorAll("script,style,noscript,svg,iframe,ins,link,img,video,audio,.google-auto-placed").forEach((n) => n.remove());
    d.querySelectorAll("*").forEach((n) => { n.removeAttribute("style"); });
    return "<!doctype html>" + d.documentElement.outerHTML;
  };
  /* dossier de l'épreuve : l'adresse peut être « …/shs », « …/shs/ » ou « …/shs/tireurs.htm » */
  const last = location.pathname.split("/").pop();
  const isFile = /\.html?$/i.test(last);
  const base = isFile ? location.pathname.replace(/[^/]*$/, "") : location.pathname.replace(/\/?$/, "/");
  const here = isFile ? last : "index.htm";
  const out = [{ path: base + here, html: clean("<html>" + document.documentElement.innerHTML + "</html>") }];
  if (!all) return Promise.resolve(out);
  const names = new Set();
  document.querySelectorAll("a[href]").forEach((a) => {
    const u = new URL(a.getAttribute("href"), location.href);
    if (u.origin === location.origin && u.pathname.startsWith(base) && /\.htm$/.test(u.pathname)) {
      const n = u.pathname.split("/").pop();
      if (n !== here && !/^(formule|videos)/.test(n)) names.add(n);
    }
  });
  return Promise.all([...names].map((n) =>
    fetch(base + n, { credentials: "same-origin" })
      .then((r) => (r.ok ? r.text() : null))
      .then((t) => (t ? { path: base + n, html: clean(t) } : null))
      .catch(() => null)
  )).then((r) => out.concat(r.filter(Boolean)));
}

const b64 = (s) => {
  const u = new TextEncoder().encode(s);
  let bin = "";
  for (let i = 0; i < u.length; i += 0x8000) bin += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
  return btoa(bin);
};

async function put(c, rel, html) {
  const path = c.folder + "/" + rel.replace(/^\/+/, "").replace(/^competition\//, "");
  const url = `https://api.github.com/repos/${c.owner}/${c.repo}/contents/${path.split("/").map(encodeURIComponent).join("/")}`;
  const H = { Authorization: "Bearer " + c.token, Accept: "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28" };
  let sha;
  const g = await fetch(url + "?ref=" + encodeURIComponent(c.branch), { headers: H });
  if (g.ok) sha = (await g.json()).sha;
  else if (g.status !== 404) throw new Error("GitHub " + g.status + (g.status === 401 ? " : jeton refusé" : ""));
  const p = await fetch(url, {
    method: "PUT", headers: H,
    body: JSON.stringify({ message: "Import En Garde : " + path, content: b64(html), branch: c.branch, sha })
  });
  if (!p.ok) throw new Error("GitHub " + p.status + " : " + (await p.text()).slice(0, 120));
}

function toast(msg, ok) {
  const d = document.createElement("div");
  d.textContent = msg;
  d.style.cssText = "position:fixed;z-index:2147483647;right:16px;bottom:16px;max-width:360px;padding:12px 16px;border-radius:10px;font:600 14px system-ui;color:#fff;box-shadow:0 6px 24px #0005;background:" + (ok ? "#16a34a" : "#dc2626");
  document.body.appendChild(d);
  setTimeout(() => d.remove(), 4500);
}
async function say(tabId, msg, ok) {
  try { await chrome.scripting.executeScript({ target: { tabId }, func: toast, args: [msg, ok] }); } catch (e) {}
  chrome.action.setBadgeBackgroundColor({ color: ok ? "#16a34a" : "#dc2626" });
  chrome.action.setBadgeText({ text: ok ? "✓" : "!" });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), 5000);
}

async function run(tab, all) {
  const c = await cfg();
  if (!c.token) { chrome.runtime.openOptionsPage(); return; }
  if (!tab || !/^https:\/\/[^/]*engarde-service\.com\/competition\//.test(tab.url || "")) {
    return say(tab && tab.id, "Ouvre d'abord une page d'épreuve En Garde (adresse …/competition/…).", false);
  }
  try {
    await say(tab.id, all ? "Envoi de toutes les pages de l'épreuve…" : "Envoi en cours…", true);
    const [{ result }] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: grab, args: [all] });
    let n = 0;
    for (const f of result) { await put(c, f.path, f.html); n++; }
    await say(tab.id, "✓ " + n + " page" + (n > 1 ? "s" : "") + " envoyée" + (n > 1 ? "s" : "") + " sur GitHub", true);
  } catch (e) {
    await say(tab.id, "Échec : " + (e && e.message || e), false);
  }
}

const active = async () => (await chrome.tabs.query({ active: true, currentWindow: true }))[0];
chrome.action.onClicked.addListener((tab) => run(tab, false));
chrome.commands.onCommand.addListener(async (cmd) => run(await active(), cmd === "send-all"));
