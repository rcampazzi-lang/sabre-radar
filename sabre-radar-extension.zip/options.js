const K=["token","owner","repo","branch","folder"],D={owner:"rcampazzi-lang",repo:"sabre-radar",branch:"main",folder:"imports",token:""};
chrome.storage.local.get(K).then(v=>{const o=Object.assign({},D,v);K.forEach(k=>document.getElementById(k).value=o[k])});
document.getElementById("save").onclick=async()=>{const o={};K.forEach(k=>o[k]=document.getElementById(k).value.trim());await chrome.storage.local.set(o);document.getElementById("ok").textContent="✓ Enregistré"};
